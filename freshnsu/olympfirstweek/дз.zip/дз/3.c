#include <stdio.h>


int main(){
    float a;
    scanf("%f", &a);
    printf("%d", (int)a, );
    //int res = fact(a);
    //printf("%d", res);
    return 0;
}